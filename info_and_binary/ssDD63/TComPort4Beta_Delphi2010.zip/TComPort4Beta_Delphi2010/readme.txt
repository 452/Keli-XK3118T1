This is subversion revision 20 of TComPort version 4.0 with minimal support (package files and .inc file updates)
for delphi 2010.

Download Location:

https://sourceforge.net/projects/comport/files/